`hour` <-
function (x) 
{
    as.numeric(format(x, "%H")) + 1
}
