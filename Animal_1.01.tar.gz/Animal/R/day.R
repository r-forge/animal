`day` <-
function (x) 
{
    as.numeric(format(x, "%d"))
}
