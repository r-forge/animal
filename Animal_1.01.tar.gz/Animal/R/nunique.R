`nunique` <-
function (x) 
(length(unique(x)))
