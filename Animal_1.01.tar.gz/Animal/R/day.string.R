`day.string` <-
function (x) 
{
    as.character(trunc(x, "days"))
}
